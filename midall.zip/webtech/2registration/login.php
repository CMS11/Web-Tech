<?php

$usr = $_POST['un']."<br>";
$Fulnam=$_POST['fn']."<br>";
$Ema=$_POST['em']."<br>";
$Phn=$_POST['ph']."<br>";
$passw=$_POST['pass']."<br>";
$ConfPassw=$_POST['cpass']."<br>";
$gender=$_POST['gndr']."<br>";
//$educa=$_POST['edu']."<br>";

echo "Your Username:".$usr;
echo "Your Fullname is:".$Fulnam;
echo "Your Email:".$Ema;
echo "Your Phone numer is:".$Phn;
echo "Your Password is:".$ConfPassw;
echo "Your Gender is:".$gender;
echo "Your Education is:";

echo "<ul>";

foreach($_POST['edu'] as $temp)
{
	
	echo "<li>".$temp."</li>";
}

echo "</ul>";









?>



