<html>
<head>
    <title>Foodie</title>
</head>
<body>
File Write:
<hr>
<form name="xmlwrite" method="post" action="mwrite.php">
    <table>
        <tr>
            <td>Menu</td>
            <td>:</td>
            <td><input type="text" name="menu" placeholder="Provide Menu Name"/></td>
        </tr>
        <tr>
            <td>Item</td>
            <td>:</td>
            <td><input type="text" name="item" placeholder="Place your Item name"/></td>
        </tr>
		<tr>
		<td>Price</td>
         <td>:</td>
         <td><input type="text" name="price" placeholder="Price of your Item"/></td>
		</tr>
        <tr>
            <td><input type="submit"/></td>
            <td><input type="reset" /> </td>
            
        </tr>
    </table>
</form>
<hr>
XML Read
<hr>
<a href='mread.php'>Read XML</a>
</body>
</html>