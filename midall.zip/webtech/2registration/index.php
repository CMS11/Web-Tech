<?php?>

<html>


    <head>
    </head>
	   
	   
	   <body>
	   
	      <form name="test" method="post" action="login.php"> 
		  
		  <h4> Personal Infromation </h4>
Username: <input type="text" name="un" /><br> 		  
Fullname: <input type="text" name="fn" /><br> 
Email:     <input type="text" name="em" /><br> 
Phone:     <input type="text" name="ph" /><br>
Password:  <input type="password" name="pass" /><br>  
Confirm Password: <input type="password" name="cpass" /><br> 
                
				<h4> Gender </h4>
				Male:   <input type = "radio" name ="gndr" value ="male"/> <br>
				Female:  <input type = "radio" name ="gndr" value ="female"/> <br>
				Other:   <input type = "radio" name ="gndr" value ="other"/> <br>
				   
				 <h4> Education </h4>
                	SSC: <input type = "checkbox" name ="edu[]" value ="SSC"/> SSC <br>
					HSC: <input type = "checkbox" name ="edu[]" value ="HSC"/> HSC <br>
					BSC: <input type = "checkbox" name ="edu[]" value ="BSC"/> BSC <br>
					MSC: <input type = "checkbox" name ="edu[]" value ="MSC"/> MSC <br>
				   
				   
                <pre>
				
				
				</pre>


                  <input type="submit" value="Send"/>
				  
				  
				  
 		        
				

			
			  
           </form>
	   
	   
	   </body>
	   
</html>	   
	   
	      