




<?php
$dom = simplexml_load_file("info.xml");

foreach($dom->userdata as $user)
{
	
	echo "Menu Name:";
	echo $user-> menu."<br>";
	echo "Item Name:";
	echo $user-> item."<br>";
	echo "Price:";
	echo $user-> price."<br>";
	

	
	
	}

?>




