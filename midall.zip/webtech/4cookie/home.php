<?php
	/*session_start();
	if (!isset($_SESSION['un'])){
		header('location:login.php');
	}*/
	
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">


    <head>
               <title> Christine's Page </title>
               <style>
			      body{
				        background-color: teal;
					  }
			      a{
				     text-decoration: none;
					 color: white;
					 font-size:24px;
					 align:center;
					 padding:15px;
				  
				  }
				</style>  
       </head>
	   
	   
	   <body>
	   
	      <hr/>
			  <a href ="home.php"><b>HOME</b></a> | <a href ="introduction.xhtml"><b>INTRODUCTION</b></a> |<a href = "education.xhtml"><b>EDUCATION</b></a>
				| <a href = "projects.xhtml"><b>PROJECTS</b></a> | <a href = "contact.xhtml"><b>CONTACT ME</b></a> |<a href = "registration.php"><b>Registration</b></a> | <a href = "login.php"><b>Login</b></a>   
		  <hr/>
		   
		  <h1 style = "text-align:center; color: navy;"> <br/> <font size="15" face="Comic Sans MS" color="navy"> WELCOME TO MY WEBPAGE </font> </h1>
	   
	     <table>
		   <tr>
	          <td> <img src = "painter.jpg"
		        alt = "painter" height = "400px" width = "433px" /> </td>
				
		       <td> <img src = "music.jpg"
		        alt = "music" height = "450px" width = "450px" /> </td>
				
		       <td> <img src = "book.jpg"
		        alt = "book" height = "400px" width = "433px" /> </td>
			</tr>
		 </table>	
		<table>
          <tr>
		     <td> <pre>                                                       </pre></td>
		     <td> <img src = "dog.jpg"
		        alt = "dog" height = "400px" width = "440px" />	</td>
		  </tr>		
		</table>
            <pre style = "text-align:center;"> <font face="Comic Sans MS">
        <hr/>
©copyright_by_christinemonishasarkar
September 2018	</font> </pre>		
		
				
				
	   
	   
	   
	   
	   </body>
	   
	</html>   