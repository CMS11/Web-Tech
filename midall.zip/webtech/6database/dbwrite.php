<?php

	$con=mysqli_connect("localhost","root","","CMS");
	$query="select * from tour";
	$rs=mysqli_query($con,$query);

	$filename="button.xml";
	$xml = new XMLWriter();
    $xml->openMemory();
    $xml->setIndent(true);
	
    $xml->startDocument('1.0', 'UTF-8');
		$xml->startElement('information');
	
			foreach($rs as $row)
			{
				$xml->startElement("data");
					$xml->writeElement("tourID",$row['id']);
					$xml->writeElement("tourCountryID",$row['country_id']);
					//$xml->writeElement("title",$row['title']);
					//$xml->writeElement("description",$row['description']);
				$xml->endElement();
			}
      
		$xml->endElement();
    $xml->endDocument();

    $file = $xml->outputMemory();
    file_put_contents($filename,$file);

echo "XML write successful! <a href='index.php'>go back</a>";
?>