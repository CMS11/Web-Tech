<?php
	$con=mysqli_connect("localhost","root","","CMS");
	$query="select * from tour";

	$rs=mysqli_query($con,$query);

	
?>
<html>
	<head>
		<title>Lab5</title>
	</head>
	<body>
	<form method="POST" action="dbwrite.php">
	  Xml:
	  <input type="submit" name="xml"/>
	  </form>
		
			<?php
				foreach($rs as $row){
					echo "<div style='background-color:cyan'>";
					echo "<h4 >Tour ID:".$row['id']." | Tour Country ID:".$row['country_id']."</h4><hr>";
					echo "<u><h4>".$row['title']."</h4></u>";
					echo "<p>".$row['description']."</p>";
					echo "</div></br>";
				}
			?>
			
		
	</body>
</html>